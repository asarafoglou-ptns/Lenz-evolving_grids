from .logic_functions import create_new_generation

__all__ = ['create_new_generation']
